/**
 * ===============================================================================
 * SquareShape.java : A shape that is a square.
 * YOUR UPI:
 * =============================================================================== */
import java.awt.*;
//Complete the SquareShape class