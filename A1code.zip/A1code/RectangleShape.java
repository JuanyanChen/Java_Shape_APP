/**
 *	===============================================================================
 *	RectangleShape.java : A shape that is a rectangle.
 *  YOUR UPI:
 *	=============================================================================== */
import java.awt.*;
//Complete the RectangleShape class